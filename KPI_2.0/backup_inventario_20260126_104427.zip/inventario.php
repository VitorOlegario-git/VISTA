<?php
require_once __DIR__ . '/../../BackEnd/helpers.php';

verificarSessao();
definirHeadersSeguranca();

$usuarioLogado = getUsuarioLogado();
$armario = sanitizeInput($_GET['armario'] ?? '');
// NOTE: support two modes:
// - legacy: accessed with ?armario=ARM-01 (single-armário view)
// - hub: accessed without armario (status × armário hub)
// If no armário is provided, do not exit — render the HUB UI (frontend JS will control filters).

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Inventário - <?php echo htmlspecialchars($armario); ?></title>
    <?php echo metaCSRF(); ?>
    <style>
    /* ======================================================
       Inventário — Estilos Mobile-first (apenas CSS)
       Objetivo: hierarquia visual, botões touch-friendly,
       estados claros e feedback leve — sem alterar JS/HTML
       ====================================================== */

    :root{
        --bg:#0b1220;
        --card-bg: rgba(255,255,255,0.04);
        --muted: #94a3b8;
        --accent: #3b82f6; /* secondary actions */
        --confirm: #10b981; /* green */
        --danger: #ef4444;  /* red */
        --card-radius: 12px;
        --gap: 12px;
        --touch-size: 48px; /* recommended touch target */
        --glass: rgba(255,255,255,0.03);
        --transition: 180ms ease;
        --text: #e5e7eb;
    }

    /* -------------------- Global -------------------- */
    html,body{height:100%;}
    body{
        font-family: Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial;
        background:var(--bg);
        color:var(--text);
        margin:0;padding:16px; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;
        -webkit-tap-highlight-color: transparent;
    }

    header h1{font-size:18px;margin:0 0 4px 0;font-weight:700}
    header p{margin:0;color:var(--muted);font-size:13px}
    /* Sticky header for quick operator context */
    header{position:sticky;top:0;z-index:60;background:linear-gradient(180deg, rgba(11,18,32,0.98), rgba(11,18,32,0.95));padding:12px;border-bottom:1px solid rgba(255,255,255,0.02)}

    /* -------------------- Cards / Blocks -------------------- */
    .card{
        background:var(--card-bg);
        padding:14px;border-radius:var(--card-radius);
        margin-bottom:var(--gap);
        box-shadow: 0 2px 6px rgba(2,6,23,0.5);
        border: 1px solid rgba(255,255,255,0.02);
    }

    /* Info summary block */
    #infoCards{display:flex;flex-direction:column;gap:8px}
    #counts{font-weight:700;font-size:15px;color:var(--text)}
    #counts small{display:block;color:var(--muted);font-weight:500}

    /* Exclusion notice */
    #excludeNotice{background:rgba(239,68,68,0.06);border-left:4px solid rgba(239,68,68,0.32);padding:10px;border-radius:8px;color:#fecaca;font-size:13px}

    /* Progress */
    #progressText{font-size:13px;color:var(--muted);font-weight:600}
    #progressWrap{width:100%}
    #progressBar{height:12px;border-radius:8px;background:var(--confirm);width:0%;transition:width var(--transition)}

    /* -------------------- Items list -------------------- */
    #itemsList{display:flex;flex-direction:column;gap:10px}
    #itemsList .item{display:flex;flex-direction:column;padding:12px;border-radius:10px;background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));border:1px solid rgba(255,255,255,0.02)}
    #itemsList .item strong{font-size:15px;display:block;color:var(--text);margin-bottom:8px}

    /* Action row inside each item: buttons full-width stacked on mobile */
    #itemsList .item > .actions { display:flex;flex-direction:column;gap:8px }
    #itemsList .item .btn{width:100%;min-height:var(--touch-size);font-size:15px;border-radius:10px;border:none}

    /* Per-action colors using data-action attribute (no JS change required) */
    button[data-action="confirm"]{background:var(--confirm);color:#06161a}
    button[data-action="confirm"]:active{transform:translateY(1px)}
    button[data-action="notfound"]{background:var(--danger);color:#fff}

    /* Generic button styles */
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 14px;font-weight:700;color:var(--text);background:transparent;border:1px solid rgba(255,255,255,0.04);min-height:var(--touch-size);border-radius:10px;transition:all var(--transition)}
    .btn:hover{filter:brightness(1.05)}
    .btn:active{transform:translateY(1px)}
    .btn[disabled],.btn.disabled{opacity:0.45;pointer-events:none}

    /* Active state for hub buttons */
    .btn.active{ background:var(--accent); color:#fff; border:none }

    /* Primary (secondary actions) kept blue when not confirm/notfound */
    .btn-primary{background:var(--accent);color:#fff;border:none}

    /* Manual entry inputs */
    section.card input, section.card input[type="number"]{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);background:transparent;color:var(--text);font-size:15px}
    label{display:inline-flex;align-items:center;gap:8px;color:var(--muted);font-size:13px}

    /* Manual list items */
    #manualList li{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.02)}

    /* Bottom fixed action area — comfortable touch targets */
    section[style*="position:fixed"]{background:transparent;padding:8px 0;z-index:40}
    section[style*="position:fixed"] .btn{min-width:80px}
    #btnRefresh{background:transparent;border:1px solid rgba(255,255,255,0.06);color:var(--text)}
    #btnContinue{background:var(--accent);color:#fff;border:none}
    #btnFinalize{background:var(--danger);color:#fff;border:none}

     /* Loading hint: reserved min-height only. Remove :empty pseudo-element
         to avoid false 'Carregando…' when backend returns an empty list. */
     #itemsList{min-height:120px}

    /* Small screens adjustments */
    @media (max-width:480px){
        body{padding:10px}
        header h1{font-size:16px}
        #itemsList .item .btn{font-size:16px}
        #counts{font-size:16px}
    }

    /* Accessibility focus */
    .btn:focus{outline:3px solid rgba(59,130,246,0.18);outline-offset:2px}

    </style>
</head>
<body>
<header>
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
        <div>
            <h1 style="margin:0;font-size:17px">
                <?php if (!empty($armario)): ?>
                    Inventário físico — Armário <?php echo htmlspecialchars($armario); ?>
                <?php else: ?>
                    Inventário físico — HUB (Status × Armário)
                <?php endif; ?>
            </h1>
            <div style="font-size:13px;color:var(--muted);margin-top:4px">Operador: <?php echo htmlspecialchars($usuarioLogado ?? ''); ?> — <span id="cycleIndicator">Ciclo: —</span></div>
        </div>
        <div style="text-align:right">
            <a href="/router_public.php?url=dashboard" class="btn" style="background:transparent;border:1px solid rgba(255,255,255,0.04);">Voltar</a>
        </div>
    </div>
</header>

<main>
    <section class="card" id="infoCards">
        <div id="counts">Carregando...</div>
        <div id="excludeNotice" style="margin-top:8px;display:none;color:#fca5a5">⚠️ Alguns registros não participam do inventário por ausência de Nota Fiscal. Esses itens não aparecem na lista e não podem ser inventariados.</div>
        <div id="progressWrap" style="margin-top:12px;display:none">
            <div id="progressText">Progresso: —</div>
            <div style="background:rgba(255,255,255,0.03);height:10px;border-radius:6px;margin-top:6px;overflow:hidden;width:100%">
                <div id="progressBar" style="height:10px;background:#10b981;width:0%"></div>
            </div>
        </div>
    </section>
    <!-- Status buttons hub (FASE 2) -->
    <section class="card" id="statusHub" style="display:block;margin-bottom:12px">
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">
            <!-- buttons injected by JS -->
            <div id="statusButtons" style="display:flex;gap:8px;flex-wrap:wrap"></div>
            <div style="margin-left:auto;color:var(--muted);font-size:13px" id="totalCounter"></div>
        </div>
        <div id="armarioButtonsWrap" style="margin-top:8px;display:none">
            <div style="display:flex;gap:8px;flex-wrap:wrap" id="armarioButtons"></div>
        </div>
    </section>

    <section class="card">
        <div style="font-size:13px;color:#94a3b8;margin-bottom:8px">Abaixo estão as remessas que o sistema espera neste armário.</div>
        <div id="itemsList">Carregando itens...</div>
        <div id="noItemsNotice" style="display:none;margin-top:8px;color:#94a3b8">Nenhuma remessa encontrada para este status/armário.</div>
    </section>

    <section class="card">
        <h2>Entrada manual — Remessas encontradas</h2>
        <div style="font-size:13px;color:#94a3b8;margin-bottom:8px">Use apenas para volumes encontrados fisicamente e não previstos pelo sistema.</div>
        <div>
            <label>Remessa (código ou ID)<input id="inpRemessa" placeholder="ABC123 / 123" style="margin-left:8px"></label>
            <label style="margin-left:8px">Quantidade (opcional)<input id="inpQtd" type="number" style="width:80px;margin-left:8px"></label>
            <label style="margin-left:8px">Observação (opcional)<input id="inpObs" placeholder="Observação" style="margin-left:8px"></label>
            <button id="btnAdd" class="btn btn-primary" style="margin-left:8px">Adicionar</button>
        </div>
        <div style="margin-top:12px">
            <ul id="manualList" style="list-style:none;padding:0;margin:0"></ul>
        </div>
        <div style="margin-top:12px">
            <button id="btnCompare" class="btn btn-primary">Enviar comparação</button>
            <span id="compareLoading" style="display:none;margin-left:8px;color:#94a3b8">Enviando comparação…</span>
        </div>
        <div id="compareResults" style="margin-top:12px"></div>
        <div id="compareHistoryWrap" style="margin-top:12px">
            <h3 style="margin:6px 0 8px 0;font-size:14px">Histórico deste armário</h3>
            <div id="compareHistory" style="font-size:13px;color:#94a3b8"></div>
        </div>
    </section>

    <section style="position:fixed;bottom:12px;left:12px;right:12px;display:flex;gap:8px;">
        <a class="btn btn-primary" id="btnRefresh" href="#">Atualizar</a>
        <a class="btn btn-primary" id="btnContinue" href="#" style="display:none">Continuar Inventário</a>
        <a class="btn" id="btnFinalize" href="#" style="background:#ef4444;color:#fff;display:none">Finalizar Inventário</a>
    </section>
</main>

<script>
const armario = '<?php echo addslashes($armario); ?>';
const csrf = document.querySelector('meta[name="csrf-token"]') ? document.querySelector('meta[name="csrf-token"]').getAttribute('content') : '';

// Global state
window.currentStatus = window.currentStatus || 'aguardando_pg'; // default
// Defensively normalize any stray suffixes if present (origin bug elsewhere)
window.currentStatus = normalizeStatus(window.currentStatus);
window.currentArmarioId = window.currentArmarioId || 0; // numeric id when available
window.currentArmarioCode = window.currentArmarioCode || (armario || ''); // original code from querystring

// Allowed status map (single source of truth for frontend)
const STATUS_MAP = [
  ['Aguardando análise',        'em_analise'],
  ['Em análise',                'em_analise'],
  ['Aguardando pagamento',      'aguardando_pg'],
  ['Em reparo',                 'em_reparo'],
  ['Aguardando NF de retorno',  'aguardando_nf_retorno'],
  ['Em análise de qualidade',   'analise_qualidade'],
  ['Expedição',                 'expedicao']
];

const allowedStatusCodes = STATUS_MAP.map(s=>s[1]);
// Normalize incoming status tokens to canonical domain used by backend
function normalizeStatus(s){
    if(!s) return 'aguardando_pg';
    s = String(s).toLowerCase().trim();
    const map = {
        'aguardando_analise': 'aguardando_pg',
        'em_analise_qualidade': 'analise_qualidade',
        'em_analise_reparo': 'em_reparo'
    };
    if(map[s]) return map[s];
    if(allowedStatusCodes.includes(s)) return s;
    return 'aguardando_pg';
}
if (!allowedStatusCodes.includes(window.currentStatus)) window.currentStatus = 'aguardando_pg';

function reloadInventario(){
    // central entry: call fetchItems and update UI state
    return fetchItems();
}

async function fetchItems(){
    const container = document.getElementById('itemsList');
    // show explicit loading indicator while request is in progress
    if (container) container.innerHTML = '<div style="color:var(--muted)">Carregando...</div>';

    // Build query using the standardized API. Prefer armario_id when set, else send armario code if present.
    const params = new URLSearchParams();
    params.append('action', 'list');
    params.append('status', normalizeStatus(window.currentStatus || 'aguardando_pg'));
    if (window.currentArmarioId && Number(window.currentArmarioId) > 0) {
        params.append('armario_id', String(window.currentArmarioId));
    } else if (window.currentArmarioCode) {
        params.append('armario', window.currentArmarioCode);
    }

    const res = await fetch('/router_public.php?url=inventario-api&' + params.toString(), {credentials:'same-origin'});
    if (res.status === 401) {
        await handleUnauthorized(res);
        return;
    }
    let data;
    try {
        data = await res.json();
    } catch (err) {
        if (container) container.innerText = 'Resposta inválida do servidor';
        return;
    }
    if(!data || data.success === false) {
        const errMsg = (data && data.error) ? data.error : 'Erro ao carregar inventário';
        showError(errMsg);
        return;
    }

    // Prefer standardized shape: data.data.items
    let rows = [];
    if (data && data.data && Array.isArray(data.data.items)) rows = data.data.items;
    else if (Array.isArray(data.data)) rows = data.data;
    else if (Array.isArray(data.items)) rows = data.items;
    else if (Array.isArray(data)) rows = data;

    // Derive and store ciclo_id and armario id from response filters (if available)
    try {
        const cicloInfo = (data && data.data && data.data.ciclo) ? data.data.ciclo : (data.ciclo || null);
        const cycleEl = document.getElementById('cycleIndicator');
        if (cycleEl) {
            if (cicloInfo && (cicloInfo.mes_ano || cicloInfo.id)) {
                cycleEl.innerText = 'Ciclo: ' + (cicloInfo.mes_ano || cicloInfo.id);
            } else {
                cycleEl.innerText = 'Ciclo: —';
            }
        }
        window.currentCicloId = (cicloInfo && cicloInfo.id) ? parseInt(cicloInfo.id) : window.currentCicloId || 0;

        // update currentArmarioId if backend returned filter normalization
        if (data && data.data && data.data.filtros && data.data.filtros.armario_id) {
            window.currentArmarioId = parseInt(data.data.filtros.armario_id) || window.currentArmarioId || 0;
        }
        if (data && data.data && data.data.armario && data.data.armario.id) {
            window.currentArmarioId = parseInt(data.data.armario.id) || window.currentArmarioId || 0;
        }
        // reflect armario selection in UI buttons if present
        if (typeof highlightArmarioButton === 'function') highlightArmarioButton(window.currentArmarioId || 0);
    } catch (e) { /* ignore */ }

    // update cycle indicator when available and store current cycle id for later actions
    try {
        const cicloInfo = (data && data.data && data.data.ciclo) ? data.data.ciclo : (data.ciclo || null);
        const cycleEl = document.getElementById('cycleIndicator');
        if (cycleEl) {
            if (cicloInfo && (cicloInfo.mes_ano || cicloInfo.id)) {
                cycleEl.innerText = 'Ciclo: ' + (cicloInfo.mes_ano || cicloInfo.id);
            } else {
                cycleEl.innerText = 'Ciclo: —';
            }
        }
        // expose current ciclo id for comparison requests
        window.currentCicloId = (cicloInfo && cicloInfo.id) ? parseInt(cicloInfo.id) : 0;
    } catch (e) { /* ignore */ }

    // compute confirmed (may be per-row flag)
    let confirmed = 0;
    rows.forEach(r => {
        const v = (r.confirmado_no_ciclo_atual ?? r.confirmado) || r.confirmado_no_ciclo || 0;
        if (parseInt(v) > 0) confirmed++;
    });
    const pending = rows.length - confirmed;
    const totalValid = rows.length; // the list returns only in-scope rows

    // Update counts and total counter in header
    document.getElementById('counts').innerText = `✔ Inventariados: ${confirmed} — ⏳ Pendentes: ${pending} — 📦 Total válido: ${totalValid}`;
    const totalCounter = document.getElementById('totalCounter');
    if (totalCounter) totalCounter.innerText = `Total: ${totalValid} remessas`;

    // reuse `container` declared at function start
    if (container) container.innerHTML = '';
    // if no rows, show explicit message (avoid :empty pseudo-element showing 'Carregando...')
    if (!rows || rows.length === 0) {
        if (container) container.innerText = '';
        document.getElementById('noItemsNotice').style.display = 'block';
        document.getElementById('counts').innerText = '✔ Inventariados: 0 — ⏳ Pendentes: 0 — 📦 Total válido: 0';
        // hide progress UI
        document.getElementById('progressWrap').style.display = 'none';
        return;
    }
    document.getElementById('noItemsNotice').style.display = 'none';

    // Render as a simple table-like list (keeping existing actions). Add Armário column (read-only).
    const table = document.createElement('div');
    table.style.display = 'flex';
    table.style.flexDirection = 'column';
    table.style.gap = '6px';

    // header row
    const headerRow = document.createElement('div');
    headerRow.style.display = 'flex'; headerRow.style.padding = '8px'; headerRow.style.fontWeight = '700'; headerRow.style.borderBottom = '1px solid rgba(255,255,255,0.03)';
    headerRow.innerHTML = `<div style="flex:2">ID / Código</div><div style="flex:3">Cliente</div><div style="flex:2">Status</div><div style="flex:1">Armário</div><div style="flex:2">Ações</div>`;
    table.appendChild(headerRow);

    rows.forEach(r => {
        const row = document.createElement('div');
        row.style.display = 'flex'; row.style.alignItems = 'center'; row.style.padding = '8px'; row.style.borderRadius = '8px'; row.style.background = 'linear-gradient(180deg, rgba(255,255,255,0.01), rgba(255,255,255,0.005))';
        const codigo = r.codigo_remessa ?? r.remessa ?? (r.id || '');
        const cliente = r.cliente_nome || '';
        const statusText = r.status || '';
        const armarioText = (r.armario_codigo || r.armario || (r.armario_id ? String(r.armario_id) : ''));
        const remessaId = r.remessa_id ?? r.resumo_id ?? r.id ?? '';

        row.innerHTML = `
            <div style="flex:2">${codigo}</div>
            <div style="flex:3;color:var(--muted)">${cliente}</div>
            <div style="flex:2;color:var(--muted)">${statusText}</div>
            <div style="flex:1;color:var(--muted)">${armarioText}</div>
            <div style="flex:2;display:flex;gap:8px">
                <button class="btn btn-primary" data-id="${remessaId}" data-action="confirm">Confirmar presença</button>
                <button class="btn" data-id="${remessaId}" data-action="notfound">Marcar como não encontrado</button>
                <button class="btn" data-id="${remessaId}" data-action="move">Mover armário</button>
            </div>
        `;
        table.appendChild(row);
    });

    container.appendChild(table);

    // bind action buttons centrally
    container.querySelectorAll('button[data-action]').forEach(btn => {
        btn.onclick = async (e) => {
            e.preventDefault();
            const id = btn.getAttribute('data-id');
            const action = btn.getAttribute('data-action');
            if(action === 'confirm'){
                await postAction('confirm', {remessa_id: id});
            } else {
                if (action === 'notfound'){
                    const obs = prompt('Observação (opcional)');
                    await postAction('notfound', {remessa_id: id, observacao: obs || ''});
                } else if (action === 'move'){
                    // prompt for armario id (could be replaced by modal)
                    const target = prompt('ID do armário destino (número)');
                    if (!target) return alert('Armário destino obrigatório');
                    const motivo = prompt('Motivo da movimentação');
                    if (!motivo) return alert('Motivo obrigatório');
                    // send PATCH request with JSON
                    await moveArmario(id, parseInt(target), motivo);
                }
            }
            await reloadInventario();
        }
    });

    // update progress UI
    const progWrap = document.getElementById('progressWrap');
    const progBar = document.getElementById('progressBar');
    const progText = document.getElementById('progressText');
    if (totalValid > 0) {
        const pct = Math.round((confirmed / totalValid) * 100);
        progText.innerText = `Progresso: ${pct}% concluído`;
        progBar.style.width = pct + '%';
        progWrap.style.display = 'block';
    } else {
        progWrap.style.display = 'none';
    }

    // fetch excluded count (resumo_geral with null/empty nota_fiscal) — read-only via existing consulta endpoint
    try {
        const r2 = await fetch('/BackEnd/Consulta/consulta_resumo_geral.php', { method: 'POST', credentials: 'same-origin' });
        if (r2.ok) {
            const j2 = await r2.json();
            const dados = j2.dados || [];
            const excluded = dados.filter(x => x.nota_fiscal === null || String(x.nota_fiscal).trim() === '').length;
            const notice = document.getElementById('excludeNotice');
            if (excluded > 0) { notice.style.display = 'block'; notice.innerText = `⚠️ ${excluded} registros não participam do inventário por ausência de Nota Fiscal. Esses itens não aparecem na lista e não podem ser inventariados.`; }
            else { notice.style.display = 'none'; }
        }
    } catch (e) {
        // ignore—do not block primary flow
    }

    // show/hide action buttons
    const btnContinue = document.getElementById('btnContinue');
    const btnFinalize = document.getElementById('btnFinalize');
    if (pending > 0) {
        btnContinue.style.display = 'inline-block';
        btnFinalize.style.display = 'none';
    } else {
        btnContinue.style.display = 'none';
        btnFinalize.style.display = 'inline-block';
    }
}

async function postAction(action, payload){
    payload.action = action;
    const form = new FormData();
    for(const k in payload) form.append(k, payload[k]);
    form.append('csrf_token', csrf);
    const res = await fetch('/router_public.php?url=inventario-api', {method:'POST', body: form, credentials:'same-origin'});
    if (res.status === 401) { await handleUnauthorized(res); return; }
    let data;
    try { data = await res.json(); } catch (err) { alert('Resposta inválida do servidor'); return; }
    if(!data.success) alert(data.error || 'Erro');
}

async function moveArmario(resumoId, armarioId, motivo){
    if (!resumoId || !armarioId) return alert('Dados inválidos para movimentação');
    const url = '/inventario/resumo/' + encodeURIComponent(resumoId) + '/armario';
    const body = { armario_id: armarioId, motivo: motivo };
    try {
        const res = await fetch(url, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrf
            },
            body: JSON.stringify(body),
            credentials: 'same-origin'
        });
        if (res.status === 401) { await handleUnauthorized(res); return; }
        let data;
        try { data = await res.json(); } catch (e) { alert('Resposta inválida do servidor'); return; }
        if (!data.success) {
            alert(data.error || 'Erro ao mover armário');
            return;
        }
        alert(data.message || 'Movimentação realizada');
    } catch (e) {
        alert('Erro ao enviar requisição');
    }
}

document.getElementById('btnRefresh').onclick = (e)=>{e.preventDefault(); reloadInventario();};
document.getElementById('btnFinalize').onclick = async (e)=>{
document.getElementById('btnContinue').onclick = (e)=>{ e.preventDefault(); const list = document.getElementById('itemsList'); if(list){ list.scrollIntoView({behavior:'smooth'}); const btn = list.querySelector('button[data-action="confirm"]'); if(btn) btn.focus(); } };

    e.preventDefault();
    if(!confirm('Encerrar ciclo atual? Apenas encerrado manualmente.')) return;
    // Para simplificar, pede ciclo_id (poderia detectar ou criar automáticamente)
    const cid = prompt('ID do ciclo a encerrar (ex: 1)');
    if(!cid) return;
    const f = new FormData(); f.append('action','finalize'); f.append('ciclo_id', cid); f.append('csrf_token', csrf);
    const res = await fetch('/router_public.php?url=inventario-api', {method:'POST', body: f, credentials:'same-origin'});
    if (res.status === 401) { await handleUnauthorized(res); return; }
    let data;
    try { data = await res.json(); } catch (err) { alert('Resposta inválida do servidor'); return; }
    if(!data.success) alert(data.error||'Erro'); else alert(data.message||'OK');
}

async function handleUnauthorized(res){
    // Try to read JSON message if available
    let msg = 'Sessão expirada ou não autenticado.';
    try {
        const j = await res.json();
        if (j && j.error) msg = j.error;
    } catch (e) {
        // ignore
    }

    // Replace main content with a friendly message and login link
    const main = document.querySelector('main');
    if (main) {
        main.innerHTML = `\n            <section class="card">\n                <h2>Autenticação necessária</h2>\n                <p>${msg}</p>\n                <p><a href="/router_public.php?url=login">Ir para a tela de login</a></p>\n            </section>`;
    } else {
        document.body.innerHTML = `<div style="padding:16px">` +
            `<h2>Autenticação necessária</h2><p>${msg}</p><p><a href="/router_public.php?url=login">Ir para a tela de login</a></p></div>`;
    }
}

// Initialize status/armario UI and load (DOMContentLoaded will call reloadInventario)
document.addEventListener('DOMContentLoaded', ()=>{
    // Status buttons definitions using single source STATUS_MAP
    const statusButtons = document.getElementById('statusButtons');
    STATUS_MAP.forEach(([label, code])=>{
        const b = document.createElement('button'); b.className='btn'; b.innerText=label; b.dataset.status = code;
        b.onclick = (e)=>{ e.preventDefault(); setStatus(code); };
        statusButtons.appendChild(b);
    });

    // Armário buttons static (ARM1..ARM5). Map to ids 1..5 for demo; can be replaced by dynamic list.
    const armarios = [ ['Todos',0], ['ARM1',1], ['ARM2',2], ['ARM3',3], ['ARM4',4], ['ARM5',5] ];
    const armarioButtons = document.getElementById('armarioButtons');
    armarios.forEach(([label,id])=>{
        const b = document.createElement('button'); b.className='btn'; b.innerText=label; b.dataset.armarioId = id;
        b.onclick = (e)=>{ e.preventDefault(); setArmario(id); };
        armarioButtons.appendChild(b);
    });

    // Initialize state from querystring / defaults
    window.currentStatus = window.currentStatus || 'aguardando_pg';
    // If page opened with ?armario=CODE, currentArmarioCode already set; currentArmarioId will be resolved by API
    highlightStatusButton(window.currentStatus);
    // show or hide armario buttons depending on status
    toggleArmarioButtons(window.currentStatus === 'aguardando_pg');

    // initial load using central function
    reloadInventario();
});

function setStatus(code){
    window.currentStatus = code;
    highlightStatusButton(code);
    toggleArmarioButtons(code === 'aguardando_pg');
    // reset armario filter when status changes (keep 'Todos')
    if(code !== 'aguardando_pg') window.currentArmarioId = 0;
    reloadInventario();
}

function setArmario(id){
    window.currentArmarioId = parseInt(id) || 0;
    // highlight
    highlightArmarioButton(window.currentArmarioId || 0);
    reloadInventario();
}

function highlightArmarioButton(id){
    document.querySelectorAll('#armarioButtons .btn').forEach(b=> b.classList.remove('active'));
    const btn = Array.from(document.querySelectorAll('#armarioButtons .btn')).find(b=>String(b.dataset.armarioId)==String(id));
    if(btn) btn.classList.add('active');
}

function highlightStatusButton(code){
    document.querySelectorAll('#statusButtons .btn').forEach(b=> b.classList.remove('active'));
    const btn = Array.from(document.querySelectorAll('#statusButtons .btn')).find(b=>b.dataset.status===code);
    if(btn) btn.classList.add('active');
}

function toggleArmarioButtons(show){
    const wrap = document.getElementById('armarioButtonsWrap');
    if(wrap) wrap.style.display = show ? 'block' : 'none';
}

// small helper to show API errors
function showError(msg){
    const container = document.getElementById('itemsList');
    if(container) container.innerHTML = '';
    const card = document.createElement('div'); card.className='card'; card.style.background = 'rgba(239,68,68,0.06)'; card.style.color='#fecaca'; card.innerText = msg;
    if(container) container.appendChild(card);
}

// (manual entry JS and remaining code kept unchanged for compatibility)
</script>

</body>
</html>
