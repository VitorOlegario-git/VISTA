-- Migration: cria tabela inventario_movimentacoes para auditoria de movimentações de armários

CREATE TABLE IF NOT EXISTS inventario_movimentacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  resumo_id INT NOT NULL,
  from_armario_id INT DEFAULT NULL,
  to_armario_id INT DEFAULT NULL,
  motivo VARCHAR(512) NOT NULL,
  movimentado_por INT NOT NULL,
  movimentado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (resumo_id),
  INDEX (from_armario_id),
  INDEX (to_armario_id)
);

-- Recomenda-se executar ALTER TABLE para adicionar FK se desejado:
-- ALTER TABLE inventario_movimentacoes ADD CONSTRAINT fk_mov_resumo FOREIGN KEY (resumo_id) REFERENCES resumo_geral(id) ON DELETE CASCADE;
-- Migration: cria tabela de movimentações de armário (auditável)

CREATE TABLE IF NOT EXISTS inventario_movimentacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  resumo_id INT NOT NULL,
  from_armario_id INT DEFAULT NULL,
  to_armario_id INT NOT NULL,
  motivo VARCHAR(255) NOT NULL,
  movimentado_por INT NOT NULL,
  movimentado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX (resumo_id),
  INDEX (from_armario_id),
  INDEX (to_armario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
