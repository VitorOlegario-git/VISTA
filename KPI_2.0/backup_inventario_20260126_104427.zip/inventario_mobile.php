<?php
require_once __DIR__ . '/../../BackEnd/helpers.php';

verificarSessao();
definirHeadersSeguranca();
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
  <title>Inventário</title>
  <?php echo metaCSRF(); ?>
  <style>
    :root{
      --bg:#071022; --card:#0f1724; --muted:#9aa4b2; --accent:#3b82f6; --confirm:#10b981; --danger:#ef4444; --glass:rgba(255,255,255,0.03);
      --touch:48px; --gap:12px; --radius:12px; --text:#e6eef8;
    }
    html,body{height:100%;}
    body{margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;color:var(--text);background:linear-gradient(180deg,#061022 0%, #071226 100%);-webkit-font-smoothing:antialiased;padding-bottom:88px}

    /* Fixed header */
    header.mobile-header{position:sticky;top:0;z-index:80;padding:12px 12px 10px;border-bottom:1px solid rgba(255,255,255,0.03);backdrop-filter:blur(6px);background:linear-gradient(180deg,rgba(5,10,18,0.92),rgba(5,10,18,0.85))}
    .h-row{display:flex;align-items:center;gap:12px}
    .title{font-size:17px;font-weight:700}
    .sub{font-size:12px;color:var(--muted)}

    /* selects large touch targets */
    .selectors{display:flex;gap:8px;margin-top:10px}
    select.mobile-select{flex:1;padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,0.04);background:var(--card);color:var(--text);font-weight:600;font-size:14px;min-height:var(--touch)}

    main{padding:12px}
    #counts{font-size:13px;color:var(--muted);margin-bottom:8px}

    /* Cards list */
    #cards{display:flex;flex-direction:column;gap:10px}
    .card{background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.02);box-shadow:0 6px 18px rgba(2,6,23,0.55)}
    .row{display:flex;justify-content:space-between;align-items:center;gap:8px}
    .meta{color:var(--muted);font-size:13px}
    .label{font-weight:700;font-size:15px}

    /* primary action and menu */
    .actions{display:flex;gap:8px;margin-top:10px}
    .btn{flex:1;min-height:44px;border-radius:10px;border:none;font-weight:700}
    .btn.primary{background:var(--confirm);color:#06161a}
    .btn.ghost{background:transparent;border:1px solid rgba(255,255,255,0.06);color:var(--text)}

    /* Bottom sheet */
    .sheet-backdrop{position:fixed;inset:0;background:rgba(0,0,0,0.45);display:none;z-index:140}
    .sheet{position:fixed;left:0;right:0;bottom:0;background:linear-gradient(180deg,#071022,#08122a);border-top-left-radius:14px;border-top-right-radius:14px;padding:12px;z-index:150;transform:translateY(100%);transition:transform .22s ease}
    .sheet.open{transform:translateY(0)}
    .sheet .item{padding:12px;border-radius:10px;background:transparent;color:var(--text);border:1px solid rgba(255,255,255,0.03);margin-bottom:8px;font-weight:700}

    /* FAB */
    .fab{position:fixed;right:16px;bottom:18px;width:56px;height:56px;border-radius:999px;background:var(--accent);display:flex;align-items:center;justify-content:center;color:#fff;font-size:26px;z-index:200;box-shadow:0 8px 20px rgba(11,24,56,0.6)}

    /* states */
    .spinner{width:36px;height:36px;border-radius:50%;border:4px solid rgba(255,255,255,0.06);border-top-color:var(--accent);animation:spin .9s linear infinite;margin:18px auto}
    @keyframes spin{to{transform:rotate(360deg)}}
    .empty{padding:24px;text-align:center;color:var(--muted)}
    .error-banner{background:#ffe1e1;color:var(--danger);padding:10px;border-radius:8px;margin-bottom:10px}

    @media(min-width:900px){ /* avoid interfering with desktop: hide mobile view on large screens */
      body{background:transparent}
      .mobile-only{display:none}
    }
  </style>
</head>
<body class="mobile-only">
  <header class="mobile-header">
    <div class="h-row">
      <div>
        <div class="title">Inventário</div>
        <div id="cycleIndicator" class="sub">Ciclo: —</div>
      </div>
      <div style="margin-left:auto;text-align:right">
        <div id="counts" class="sub">—</div>
      </div>
    </div>

    <div class="selectors">
      <select id="statusSelect" class="mobile-select" aria-label="Filtrar por status"></select>
      <select id="armarioSelect" class="mobile-select" aria-label="Filtrar por armário" style="display:none"></select>
    </div>
  </header>

  <main>
    <div id="alerts"></div>
    <div id="content">
      <div id="loading" class="spinner" style="display:none" aria-hidden="true"></div>
      <div id="error" class="error-banner" style="display:none"></div>
      <div id="cards"></div>
      <div id="empty" class="empty" style="display:none">Nenhuma remessa para este filtro</div>
    </div>
  </main>

  <!-- bottom sheet -->
  <div id="sheetBackdrop" class="sheet-backdrop"></div>
  <div id="sheet" class="sheet" role="dialog" aria-hidden="true">
    <div id="sheetTitle" style="font-weight:800;margin-bottom:8px">Ações</div>
    <div id="sheetBody"></div>
  </div>

  <!-- move modal (inside sheet) -->
  <template id="moveTemplate">
    <div>
      <div style="font-weight:700;margin-bottom:8px">Mover armário</div>
      <select id="moveArmarioSelect" style="width:100%;padding:10px;border-radius:8px;margin-bottom:8px"></select>
      <input id="moveReason" placeholder="Motivo (obrigatório)" style="width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);margin-bottom:8px;color:var(--text);background:transparent" />
      <div style="display:flex;gap:8px">
        <button id="moveConfirm" class="btn primary">Confirmar</button>
        <button id="moveCancel" class="btn ghost">Cancelar</button>
      </div>
    </div>
  </template>

  <button id="fab" class="fab" aria-label="Adicionar remessa">+</button>

  <script>
  (function(){
    // Centralized JS state
    window.currentStatus = window.currentStatus || 'aguardando_pg';
    // Defensive normalization to remove any accidental suffixes introduced by external integrations
    window.currentStatus = normalizeStatus(window.currentStatus);
    window.currentArmarioId = window.currentArmarioId || 0;
    window.currentCicloId = window.currentCicloId || 0;
    const csrf = document.querySelector('meta[name="csrf-token"]') ? document.querySelector('meta[name="csrf-token"]').getAttribute('content') : '';

    const statusSelect = document.getElementById('statusSelect');
    const armarioSelect = document.getElementById('armarioSelect');
    const cards = document.getElementById('cards');
    const loading = document.getElementById('loading');
    const error = document.getElementById('error');
    const empty = document.getElementById('empty');
    const counts = document.getElementById('counts');

    const sheet = document.getElementById('sheet');
    const sheetBackdrop = document.getElementById('sheetBackdrop');
    const sheetBody = document.getElementById('sheetBody');

    const STATUS_MAP = [
      ['Aguardando análise',        'em_analise'],
      ['Em análise',                'em_analise'],
      ['Aguardando pagamento',      'aguardando_pg'],
      ['Em reparo',                 'em_reparo'],
      ['Aguardando NF de retorno',  'aguardando_nf_retorno'],
      ['Em análise de qualidade',   'analise_qualidade'],
      ['Expedição',                 'expedicao']
    ];

    // Ensure currentStatus is a valid code from STATUS_MAP
    const allowedStatusCodes = STATUS_MAP.map(s=>s[1]);
    // Normalize incoming status tokens to canonical domain used by backend
    function normalizeStatus(s){
      if(!s) return 'aguardando_pg';
      s = String(s).toLowerCase().trim();
      const map = {
        'aguardando_analise': 'aguardando_pg',
        'em_analise_qualidade': 'analise_qualidade',
        'em_analise_reparo': 'em_reparo'
      };
      if(map[s]) return map[s];
      if(allowedStatusCodes.includes(s)) return s;
      return 'aguardando_pg';
    }
    if (!allowedStatusCodes.includes(window.currentStatus)) {
      window.currentStatus = 'aguardando_pg';
    }

    // populate status select
    STATUS_MAP.forEach(([label,code]) => {
      const o = document.createElement('option'); o.value = code; o.textContent = label; statusSelect.appendChild(o);
    });
    statusSelect.value = window.currentStatus;

    function showLoading(){ loading.style.display='block'; error.style.display='none'; empty.style.display='none'; }
    function hideLoading(){ loading.style.display='none'; }
    function showError(msg){ error.style.display='block'; error.textContent = msg; }
    function clearError(){ error.style.display='none'; error.textContent=''; }
    function showEmpty(){ empty.style.display='block'; }
    function hideEmpty(){ empty.style.display='none'; }

    // Fetch armarios list dynamically
    async function fetchArmarios(){
      try{
        const res = await fetch('/router_public.php?url=BackEnd/Inventario/Armario.php', {credentials:'same-origin'});
        if(res.status===401) return [];
        const j = await res.json();
        // Expect payload.success + data.items OR data.armarios
        if(j && j.success && j.data && Array.isArray(j.data.items)) return j.data.items;
        if(j && Array.isArray(j.armarios)) return j.armarios;
        if(Array.isArray(j)) return j;
        return [];
      }catch(e){ return []; }
    }

    // show or hide armario select based on status
    function toggleArmarioVisibility(code){ if(code === 'aguardando_pg'){ armarioSelect.style.display='block'; } else { armarioSelect.style.display='none'; window.currentArmarioId = 0; } }

    // Populate armario select with 'Todos' option
    async function populateArmarios(){
      const list = await fetchArmarios();
      armarioSelect.innerHTML = '';
      const all = document.createElement('option'); all.value = '0'; all.textContent = 'Todos'; armarioSelect.appendChild(all);
      list.forEach(a => {
        const o = document.createElement('option'); o.value = a.id || a.armario_id || a.armario || a.codigo || 0; o.textContent = (a.codigo || a.nome || a.descricao || ('Armário ' + (a.id||'')));
        armarioSelect.appendChild(o);
      });
      // keep previously selected if present
      if(window.currentArmarioId) armarioSelect.value = String(window.currentArmarioId);
    }

    // Centralized reload function
    async function reloadInventario(){
      showLoading(); clearError(); hideEmpty(); cards.innerHTML = '';
      const params = new URLSearchParams(); params.append('action','list'); params.append('status', normalizeStatus(window.currentStatus || 'aguardando_pg'));
      if(window.currentArmarioId && Number(window.currentArmarioId) > 0) params.append('armario_id', String(window.currentArmarioId));
      try{
        const res = await fetch('/router_public.php?url=inventario-api&' + params.toString(), {credentials:'same-origin'});
        if(res.status===401){ handleUnauthorized(); return; }
        const j = await res.json();
        if(!j || j.success===false){ hideLoading(); showError(j && (j.error || j.message) ? (j.error || j.message) : 'Erro ao carregar'); return; }

        // parse items
        let rows = [];
        if(j.data && Array.isArray(j.data.items)) rows = j.data.items; else if(Array.isArray(j.data)) rows = j.data; else if(Array.isArray(j.items)) rows = j.items;

        // update counts and cycle
        const ciclo = (j.data && j.data.ciclo) ? j.data.ciclo : (j.ciclo || null);
        document.getElementById('cycleIndicator').innerText = ciclo ? ('Ciclo: ' + (ciclo.mes_ano || ciclo.id)) : 'Ciclo: —';
        window.currentCicloId = ciclo && ciclo.id ? Number(ciclo.id) : window.currentCicloId || 0;

        if(rows.length === 0){ hideLoading(); showEmpty(); counts.innerText = '0 remessas'; return; }

        // render cards
        rows.forEach(r => {
          const card = document.createElement('div'); card.className='card';
          const codigo = r.codigo_rastreio_entrada || r.remessa || r.codigo_remessa || r.id || '';
          const nf = r.nota_fiscal || r.nf || r.nota_fiscal_entrada || '';
          const cliente = r.razao_social || r.cliente || r.cliente_nome || '';
          const arm = r.armario_codigo || r.armario || (r.armario_id ? String(r.armario_id) : '—');
          const remessaId = r.remessa_id || r.resumo_id || r.id || '';

          card.innerHTML = `
            <div class="row"><div>
              <div class="label">${escapeHtml(codigo)}</div>
              <div class="meta">NF: ${escapeHtml(nf)} • ${escapeHtml(cliente)}</div>
            </div><div class="meta">${escapeHtml(arm)}</div></div>
            `;

          const actions = document.createElement('div'); actions.className='actions';
          const btnConfirm = document.createElement('button'); btnConfirm.className='btn primary'; btnConfirm.textContent='✔ Confirmar'; btnConfirm.dataset.id = remessaId;
          const btnMenu = document.createElement('button'); btnMenu.className='btn ghost'; btnMenu.textContent='⋮'; btnMenu.dataset.id = remessaId; btnMenu.dataset.payload = JSON.stringify(r);
          actions.appendChild(btnConfirm); actions.appendChild(btnMenu);
          card.appendChild(actions);

          // bind actions
          btnConfirm.addEventListener('click', async (e)=>{ e.preventDefault(); btnConfirm.disabled=true; await postAction('confirm',{ remessa_id: remessaId }); await reloadInventario(); btnConfirm.disabled=false; });
          btnMenu.addEventListener('click', (e)=>{ e.preventDefault(); openSheetFor(remessaId, r); });

          cards.appendChild(card);
        });

        counts.innerText = `${rows.length} remessas`;
        hideLoading();
      }catch(err){ hideLoading(); showError('Erro de rede ao consultar o inventário'); }
    }

    // escape helper
    function escapeHtml(s){ if(!s) return ''; return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[c];}); }

    // use existing POST action contract used by desktop view
    async function postAction(action, payload){
      payload = payload || {};
      payload.action = action;
      const form = new FormData(); for(const k in payload) form.append(k, payload[k]);
      if(csrf) form.append('csrf_token', csrf);
      const res = await fetch('/router_public.php?url=inventario-api', { method:'POST', body: form, credentials:'same-origin' });
      if(res.status===401){ handleUnauthorized(); return; }
      const j = await res.json(); if(!j.success) showError(j.error||j.message||'Erro');
    }

    // move armario via PATCH to existing endpoint
    async function moveArmario(resumoId, armarioId, motivo){
      const url = '/router_public.php?url=inventario/resumo/' + encodeURIComponent(resumoId) + '/armario';
      const body = { armario_id: Number(armarioId), motivo: String(motivo) };
      try{
        const res = await fetch(url, { method:'PATCH', headers: { 'Content-Type':'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(body), credentials:'same-origin' });
        if(res.status===401){ handleUnauthorized(); return false; }
        const j = await res.json(); if(!j.success){ showError(j.error||j.message||'Erro ao mover armário'); return false; }
        return true;
      }catch(e){ showError('Erro de rede'); return false; }
    }

    function handleUnauthorized(){ document.body.innerHTML = '<main style="padding:16px"><h2>Autenticação necessária</h2><p>Sua sessão expirou. Faça login.</p><p><a href="/router_public.php?url=login">Entrar</a></p></main>'; }

    // bottom sheet logic
    function openSheetFor(remessaId, payload){
      sheetBody.innerHTML = '';
      const moveBtn = document.createElement('div'); moveBtn.className='item'; moveBtn.textContent='Mover armário'; moveBtn.addEventListener('click', ()=>{ renderMoveModal(remessaId); });
      const notFoundBtn = document.createElement('div'); notFoundBtn.className='item'; notFoundBtn.textContent='Marcar como não encontrado'; notFoundBtn.addEventListener('click', ()=>{ renderNotFoundModal(remessaId); });
      const histBtn = document.createElement('div'); histBtn.className='item'; histBtn.textContent='Ver histórico'; histBtn.addEventListener('click', ()=>{ window.location.href = '/router_public.php?url=inventario/atribuicoes&resumo_id=' + encodeURIComponent(remessaId); });
      sheetBody.appendChild(moveBtn); sheetBody.appendChild(notFoundBtn); sheetBody.appendChild(histBtn);
      sheetBackdrop.style.display='block'; sheet.classList.add('open'); sheet.setAttribute('aria-hidden','false');
      sheetBackdrop.onclick = closeSheet;
    }
    function closeSheet(){ sheet.classList.remove('open'); sheetBackdrop.style.display='none'; sheet.setAttribute('aria-hidden','true'); }

    // render move modal inside sheet
    async function renderMoveModal(remessaId){
      sheetBody.innerHTML = '';
      const tpl = document.getElementById('moveTemplate'); const node = tpl.content.cloneNode(true);
      const select = node.getElementById('moveArmarioSelect'); const reason = node.getElementById('moveReason'); const confirm = node.getElementById('moveConfirm'); const cancel = node.getElementById('moveCancel');
      // populate armarios
      const list = await fetchArmarios();
      list.forEach(a=>{ const o=document.createElement('option'); o.value = a.id || a.armario_id || a.codigo || 0; o.textContent = (a.codigo || a.nome || a.descricao || ('Armário ' + (a.id||''))); select.appendChild(o); });

      confirm.addEventListener('click', async ()=>{
        const target = select.value; const motivo = reason.value.trim();
        if(!target){ alert('Selecione o armário destino'); return; }
        if(!motivo){ alert('Motivo obrigatório'); return; }
        confirm.disabled = true;
        const ok = await moveArmario(remessaId, target, motivo);
        confirm.disabled = false;
        if(ok){ closeSheet(); await reloadInventario(); }
      });
      cancel.addEventListener('click', ()=>{ closeSheet(); });
      sheetBody.appendChild(node);
    }

    // render not found modal (simple input for observation)
    function renderNotFoundModal(remessaId){
      sheetBody.innerHTML = '';
      const wrapper = document.createElement('div');
      const ta = document.createElement('input'); ta.placeholder='Observação (opcional)'; ta.style.width='100%'; ta.style.padding='10px'; ta.style.marginBottom='8px'; ta.style.borderRadius='8px'; ta.style.border='1px solid rgba(255,255,255,0.04)';
      const btns = document.createElement('div'); btns.style.display='flex'; btns.style.gap='8px';
      const ok = document.createElement('button'); ok.className='btn primary'; ok.textContent='Confirmar';
      const can = document.createElement('button'); can.className='btn ghost'; can.textContent='Cancelar';
      ok.addEventListener('click', async ()=>{ ok.disabled=true; await postAction('notfound', { remessa_id: remessaId, observacao: ta.value || '' }); ok.disabled=false; closeSheet(); await reloadInventario(); });
      can.addEventListener('click', ()=>{ closeSheet(); });
      btns.appendChild(ok); btns.appendChild(can);
      wrapper.appendChild(ta); wrapper.appendChild(btns); sheetBody.appendChild(wrapper);
    }

    // FAB behaviour: open manual entry simple screen (reuse existing cadastro view to avoid backend changes)
    document.getElementById('fab').addEventListener('click', ()=>{
      // open simple inline form
      sheetBody.innerHTML = '';
      const form = document.createElement('div');
      form.innerHTML = '<div style="font-weight:800;margin-bottom:8px">Entrada manual</div>' +
        '<input id="manualCode" placeholder="Código da remessa" style="width:100%;padding:10px;border-radius:8px;margin-bottom:8px;border:1px solid rgba(255,255,255,0.04);background:transparent;color:var(--text)" />' +
        '<input id="manualQty" placeholder="Quantidade (opcional)" style="width:100%;padding:10px;border-radius:8px;margin-bottom:8px;border:1px solid rgba(255,255,255,0.04);background:transparent;color:var(--text)" />' +
        '<div style="display:flex;gap:8px"><button id="manualConfirm" class="btn primary">Confirmar</button><button id="manualCancel" class="btn ghost">Cancelar</button></div>';
      sheetBody.appendChild(form);
      sheetBackdrop.style.display='block'; sheet.classList.add('open'); sheet.setAttribute('aria-hidden','false');

      document.getElementById('manualCancel').addEventListener('click', closeSheet);
      document.getElementById('manualConfirm').addEventListener('click', async ()=>{
        const code = document.getElementById('manualCode').value.trim(); const qty = document.getElementById('manualQty').value.trim();
        if(!code){ alert('Código da remessa obrigatório'); return; }
        // Reuse existing cadastro route by navigating with query params (keeps backend untouched)
        // This opens the cadastro page where the operator can finalize the entry.
        const url = '/router_public.php?url=cadastro-entrada&codigo=' + encodeURIComponent(code) + '&quantidade=' + encodeURIComponent(qty || '');
        window.location.href = url;
      });
    });

    // listeners for selects
    statusSelect.addEventListener('change', async function(){ window.currentStatus = this.value; toggleArmarioVisibility(this.value); if(this.value === 'aguardando_pg') await populateArmarios(); await reloadInventario(); });
    armarioSelect.addEventListener('change', async function(){ window.currentArmarioId = Number(this.value || 0); await reloadInventario(); });

    // initialize
    (async function init(){ toggleArmarioVisibility(window.currentStatus); if(window.currentStatus === 'aguardando_pg') await populateArmarios(); await reloadInventario(); })();

    // expose reload globally for debugging
    window.reloadInventario = reloadInventario;
  })();
  </script>
</body>
</html>
